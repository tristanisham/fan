#!/usr/bin/env bash

FAN_LIB=./lang ./build/fan $@
