#pragma once

namespace cli {

void print_help();
void print_version();

  
}  // namespace cli
