#!/usr/bin/env bash

VOID_LIB=./lang ./build/void $@
