# Void's Standard Library

This folder and its subsequent subdirectories contains Void's Standard Library. If you're looking for a function's C++ bindings, check `src/vm/`.

Contribute by [adding your own embeddings](https://wren.io/embedding/).
